# ubigeo-peru
Base de datos de departamentos, provincias y distritos del Perú (UBIGEO) actualizada al 2019 (El INEI ha actualizado hasta el 2016). SQL, JSON, XML, CSV, Arreglos PHP, YAML.

En SQL los nombres de las columnas están en inglés: Regions = Departamentos, Provinces = Provincias, Districts = Distritos.
